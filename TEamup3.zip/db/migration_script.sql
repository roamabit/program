-- ----------------------------------------------------------------------------
-- MySQL Workbench Migration
-- Migrated Schemata: development
-- Source Schemata: development
-- Created: Thu Feb 12 12:13:12 2015
-- ----------------------------------------------------------------------------

SET FOREIGN_KEY_CHECKS = 0;;

-- ----------------------------------------------------------------------------
-- Schema development
-- ----------------------------------------------------------------------------
DROP SCHEMA IF EXISTS `development` ;
CREATE SCHEMA IF NOT EXISTS `development` ;

-- ----------------------------------------------------------------------------
-- View development.ProposeProjects
-- ----------------------------------------------------------------------------
-- USE `development`;
-- CREATE  OR REPLACE VIEW ProposeProjects AS Select * from projects;
SET FOREIGN_KEY_CHECKS = 1;;
