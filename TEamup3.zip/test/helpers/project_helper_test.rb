require 'test_helper'

class ProjectHelperTest < ActionView::TestCase
end
