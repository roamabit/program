require 'test_helper'

class SupportersHelperTest < ActionView::TestCase
end
