require 'test_helper'

class SolutionsHelperTest < ActionView::TestCase
end
