require 'test_helper'

class LinksHelperTest < ActionView::TestCase
end
