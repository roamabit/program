require 'test_helper'

class PartnershipTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
