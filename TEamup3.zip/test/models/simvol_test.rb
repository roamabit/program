require 'test_helper'

class SimvolTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
