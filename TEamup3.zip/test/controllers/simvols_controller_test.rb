require 'test_helper'

class SimvolsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
