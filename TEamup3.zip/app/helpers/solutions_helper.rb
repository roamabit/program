module SolutionsHelper
end
