run "ln -nfs #{paths.shared_config}/secrets.yml #{paths.active_release_config}/secrets.yml"
