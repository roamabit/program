require 'test_helper'

class ProfilesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
