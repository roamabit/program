require 'test_helper'

class PartnershipsHelperTest < ActionView::TestCase
end
