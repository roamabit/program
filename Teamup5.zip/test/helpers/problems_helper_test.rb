require 'test_helper'

class ProblemsHelperTest < ActionView::TestCase
end
