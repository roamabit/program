require 'test_helper'

class SearchProblemsHelperTest < ActionView::TestCase
end
