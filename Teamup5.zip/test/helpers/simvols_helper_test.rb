require 'test_helper'

class SimvolsHelperTest < ActionView::TestCase
end
