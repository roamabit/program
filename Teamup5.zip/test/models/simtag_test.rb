require 'test_helper'

class SimtagTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
