require 'test_helper'

class SearchProblemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
